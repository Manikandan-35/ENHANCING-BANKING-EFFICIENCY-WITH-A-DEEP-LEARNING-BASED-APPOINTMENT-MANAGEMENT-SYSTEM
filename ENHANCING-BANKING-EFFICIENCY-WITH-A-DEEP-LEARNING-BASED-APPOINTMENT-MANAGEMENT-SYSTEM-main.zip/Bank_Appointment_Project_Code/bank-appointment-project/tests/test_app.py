"""Integration checks using actual HTTP forms and isolated SQLite databases."""
from concurrent.futures import ThreadPoolExecutor
from datetime import timedelta
from pathlib import Path
import re
import tempfile
import threading
import unittest
from unittest.mock import patch

from werkzeug.security import generate_password_hash
from app import create_app, now, stamp
from database import Database
from predictor import DemandPredictor
from train_model import load_history

ROOT = Path(__file__).resolve().parents[1]


class AppointmentTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.app = create_app({"TESTING": True, "SECRET_KEY": "test-only-secret",
                               "DATABASE_PATH": str(Path(self.temp.name) / "test.db"),
                               "DB_ENGINE": "sqlite"})
        self.client = self.app.test_client()
        self.other = self.app.test_client()
        self.day = now().date() + timedelta(days=2)
        while self.day.weekday() == 6:
            self.day += timedelta(days=1)
        self.register(self.client, "mani@example.com", "Mani")
        self.register(self.other, "other@example.com", "Other Customer")
        self.signin(self.client, "mani@example.com")
        self.signin(self.other, "other@example.com")

    def tearDown(self):
        self.temp.cleanup()

    def db(self):
        return Database(self.app.config)

    def rows(self, query, params=()):
        db = self.db()
        try:
            return db.query(query, params)
        finally:
            db.close()

    def token(self, client, path="/dashboard"):
        page = client.get(path)
        match = re.search(rb'name="csrf_token" value="([^"]+)"', page.data)
        self.assertIsNotNone(match)
        return match.group(1).decode()

    def post(self, client, path, data=None, get_path="/dashboard"):
        body = dict(data or {})
        body["csrf_token"] = self.token(client, get_path)
        return client.post(path, data=body)

    def register(self, client, email, name):
        return self.post(client, "/register", {"name": name, "email": email,
            "password": "StrongDemo123!", "confirm_password": "StrongDemo123!"}, "/register")

    def signin(self, client, email, password="StrongDemo123!"):
        return self.post(client, "/login", {"email": email, "password": password}, "/login")

    def booking(self, time="10:00", **updates):
        values = {"branch_id": "1", "service_id": "1", "appointment_date": self.day.isoformat(),
                  "appointment_time": time, "notes": "Need account opening information"}
        values.update(updates)
        return values

    def make_admin(self):
        db = self.db()
        try:
            db.execute("INSERT INTO users (name, email, password_hash, role, created_at) VALUES (?, ?, ?, 'admin', ?)",
                       ("Administrator", "admin@example.com", generate_password_hash("StrongDemo123!"), stamp()))
        finally:
            db.close()
        client = self.app.test_client()
        self.signin(client, "admin@example.com")
        return client

    def test_full_customer_journey(self):
        result = self.post(self.client, "/appointments/new", self.booking())
        self.assertEqual(result.status_code, 303)
        row = self.rows("SELECT * FROM appointments")[0]
        dashboard = self.client.get("/dashboard")
        self.assertIn(b"Account Opening", dashboard.data)
        self.assertIn(b"10:00 IST", dashboard.data)
        self.assertEqual(self.post(self.client, f"/appointments/{row['id']}/edit", self.booking("11:00")).status_code, 303)
        self.assertEqual(self.rows("SELECT appointment_time FROM appointments")[0]["appointment_time"], "11:00")
        self.assertEqual(self.post(self.client, f"/appointments/{row['id']}/cancel").status_code, 303)
        cancelled = self.rows("SELECT * FROM appointments")[0]
        self.assertEqual(cancelled["status"], "cancelled")
        self.assertIsNone(cancelled["active_slot_key"])
        self.assertEqual(self.post(self.client, "/logout").status_code, 303)
        self.assertEqual(self.client.get("/dashboard").status_code, 302)

    def test_duplicate_slot_rejected_and_released_on_cancellation(self):
        self.assertEqual(self.post(self.client, "/appointments/new", self.booking()).status_code, 303)
        self.assertEqual(self.post(self.other, "/appointments/new", self.booking()).status_code, 409)
        appointment_id = self.rows("SELECT id FROM appointments")[0]["id"]
        self.post(self.client, f"/appointments/{appointment_id}/cancel")
        self.assertEqual(self.post(self.other, "/appointments/new", self.booking()).status_code, 303)
        self.assertEqual(len(self.rows("SELECT id FROM appointments WHERE status='booked'")), 1)

    def test_conflicting_reschedule_keeps_original_slot(self):
        self.post(self.client, "/appointments/new", self.booking("10:00"))
        self.post(self.other, "/appointments/new", self.booking("11:00"))
        appointment_id = self.rows("SELECT id FROM appointments ORDER BY id")[0]["id"]
        result = self.post(self.client, f"/appointments/{appointment_id}/edit", self.booking("11:00"))
        self.assertEqual(result.status_code, 409)
        self.assertEqual(self.rows("SELECT appointment_time FROM appointments WHERE id=?", (appointment_id,))[0]["appointment_time"], "10:00")
        self.assertEqual(len(self.rows("SELECT id FROM appointments WHERE active_slot_key IS NOT NULL")), 2)

    def test_parallel_booking_has_one_winner(self):
        barrier = threading.Barrier(2)
        clients = [self.client, self.other]
        tokens = [self.token(client) for client in clients]
        def submit(index):
            data = self.booking()
            data["csrf_token"] = tokens[index]
            barrier.wait()
            return clients[index].post("/appointments/new", data=data).status_code
        with ThreadPoolExecutor(max_workers=2) as pool:
            statuses = list(pool.map(submit, [0, 1]))
        self.assertEqual(sorted(statuses), [303, 409])
        self.assertEqual(len(self.rows("SELECT id FROM appointments")), 1)

    def test_ownership_and_admin_access(self):
        self.post(self.client, "/appointments/new", self.booking())
        appointment_id = self.rows("SELECT id FROM appointments")[0]["id"]
        self.assertEqual(self.other.get(f"/appointments/{appointment_id}/edit").status_code, 403)
        self.assertEqual(self.post(self.other, f"/appointments/{appointment_id}/cancel").status_code, 403)
        self.assertEqual(self.client.get("/admin").status_code, 403)
        self.assertEqual(self.client.get("/admin/forecast").status_code, 403)
        self.assertEqual(self.other.get(f"/api/slots?branch_id=1&service_id=1&date={self.day}&exclude_id={appointment_id}").status_code, 403)
        admin = self.make_admin()
        self.assertEqual(admin.get("/admin").status_code, 200)
        self.assertEqual(self.post(admin, f"/appointments/{appointment_id}/cancel", get_path="/admin").status_code, 303)
        actions = [r["action"] for r in self.rows("SELECT action FROM audit_logs")]
        self.assertIn("book", actions)
        self.assertIn("cancel", actions)

    def test_admin_completion_only_after_start(self):
        self.post(self.client, "/appointments/new", self.booking())
        appointment_id = self.rows("SELECT id FROM appointments")[0]["id"]
        admin = self.make_admin()
        path = f"/admin/appointments/{appointment_id}/complete"
        self.assertEqual(self.post(admin, path, get_path="/admin").status_code, 409)
        later = now() + timedelta(days=4)
        with patch("app.now", return_value=later):
            self.assertEqual(self.post(admin, path, get_path="/admin").status_code, 303)
        self.assertEqual(self.rows("SELECT status FROM appointments")[0]["status"], "completed")

    def test_csrf_and_authentication(self):
        self.assertEqual(self.client.post("/appointments/new", data=self.booking()).status_code, 400)
        anonymous = self.app.test_client()
        self.assertEqual(anonymous.get("/appointments/new").status_code, 302)
        self.assertEqual(self.signin(anonymous, "mani@example.com", "wrong").status_code, 400)
        old_token = self.token(anonymous, "/login")
        self.assertEqual(self.signin(anonymous, "mani@example.com").status_code, 303)
        self.assertEqual(anonymous.post("/logout", data={"csrf_token": old_token}).status_code, 400)

    def test_duplicate_email_and_customer_only_registration(self):
        new_client = self.app.test_client()
        result = self.register(new_client, "MANI@EXAMPLE.COM", "Duplicate")
        self.assertEqual(result.status_code, 400)
        self.assertEqual(self.post(new_client, "/register", {"name": "New Customer", "email": "new@example.com",
            "password": "StrongDemo123!", "confirm_password": "StrongDemo123!", "role": "admin"}, "/register").status_code, 303)
        self.assertEqual(self.rows("SELECT role FROM users WHERE email=?", ("new@example.com",))[0]["role"], "customer")
        hashes = self.rows("SELECT password_hash FROM users")
        self.assertTrue(all(r["password_hash"] != "StrongDemo123!" for r in hashes))

    def test_invalid_days_slots_and_notes(self):
        sunday = self.day
        while sunday.weekday() != 6:
            sunday += timedelta(days=1)
        cases = [{"appointment_date": (now().date() - timedelta(days=1)).isoformat()},
                 {"appointment_date": sunday.isoformat()}, {"appointment_time": "10:17"},
                 {"branch_id": "999"}, {"service_id": "abc"}, {"notes": "x" * 501},
                 {"appointment_date": (now().date() + timedelta(days=61)).isoformat()}]
        for update in cases:
            with self.subTest(update=update):
                self.assertEqual(self.post(self.client, "/appointments/new", self.booking(**update)).status_code, 400)
        self.assertEqual(len(self.rows("SELECT id FROM appointments")), 0)

    def test_slot_api_and_forecast(self):
        self.post(self.client, "/appointments/new", self.booking())
        response = self.client.get(f"/api/slots?branch_id=1&service_id=1&date={self.day}")
        self.assertEqual(response.status_code, 200)
        slots = response.json["slots"]
        self.assertEqual(len(slots), 14)
        self.assertFalse(next(r for r in slots if r["time"] == "10:00")["available"])
        self.assertTrue(all(0 <= r["demand"] <= 30 for r in slots))
        self.assertEqual(response.json["data_source"], "synthetic_demo")
        self.assertEqual(self.client.get("/api/slots?date=bad").status_code, 400)
        admin = self.make_admin()
        self.assertEqual(admin.get("/admin/forecast").status_code, 200)

    def test_cancelled_appointment_cannot_be_modified_or_cancelled_twice(self):
        self.post(self.client, "/appointments/new", self.booking())
        appointment_id = self.rows("SELECT id FROM appointments")[0]["id"]
        self.post(self.client, f"/appointments/{appointment_id}/cancel")
        self.assertEqual(self.client.get(f"/appointments/{appointment_id}/edit").status_code, 409)
        self.assertEqual(self.post(self.client, f"/appointments/{appointment_id}/cancel").status_code, 409)

    def test_html_escaping_and_parameterized_notes(self):
        text = "<script>alert('x')</script> '; DROP TABLE users; --"
        self.post(self.client, "/appointments/new", self.booking(notes=text))
        page = self.client.get("/dashboard")
        self.assertNotIn(b"<script>alert", page.data)
        self.assertIn(b"&lt;script&gt;", page.data)
        self.assertEqual(len(self.rows("SELECT id FROM users")), 2)
        self.assertEqual(page.headers["X-Frame-Options"], "DENY")
        self.assertIn("default-src 'self'", page.headers["Content-Security-Policy"])


class ModelTests(unittest.TestCase):
    def test_training_rejects_invalid_time_values(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "invalid.csv"
            path.write_text("date,time,service_id,branch_factor,customer_count\n2026-10-10,25:00,1,1.0,8\n", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "Invalid CSV row 2"):
                load_history(path)

    def test_packaged_neural_network_is_finite_and_reproducible(self):
        model = DemandPredictor(ROOT / "data" / "demand_model.npz")
        self.assertTrue(model.available)
        p1 = model.predict("2026-10-10", "10:00", 1, 1.0)
        p2 = model.predict("2026-10-10", "10:00", 1, 1.0)
        self.assertEqual(p1, p2)
        self.assertTrue(0 <= p1 <= 30)
        self.assertEqual(model.metadata["architecture"], [11, 24, 12, 1])
        self.assertEqual(model.metadata["data_source"], "synthetic_demo")
        self.assertLess(model.metadata["validation_mae"], 2.5)

    def test_missing_model_is_explicitly_unavailable(self):
        model = DemandPredictor(ROOT / "data" / "missing-model.npz")
        self.assertFalse(model.available)
        self.assertIsNone(model.predict("2026-10-10", "10:00", 1))


if __name__ == "__main__":
    unittest.main()
