# Mani - Project run panna steps

Indha folder-la working project code irukku. Laptop/PC-la Python 3.10+ install panni run pannalam.

## Windows-la run panna

1. ZIP-a extract pannu.
2. `bank-appointment-project` folder-a VS Code-la open pannu.
3. Terminal open panni indha commands-a one by one run pannu:

```powershell
py -3 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe app.py
```

4. Chrome-la `http://127.0.0.1:5000` open pannu.
5. Create account click panni register pannu.
6. Sign in panni branch, service, date, time select panni appointment book pannu.
7. My appointments-la Modify / Cancel use pannalam.

SQLite database automatic-a create aagum. Mudhal demo-ku MySQL install panna thevai illa. MySQL use panna README-la optional setup irukku.

## Admin dashboard venumna

Running terminal-la `Ctrl+C` press panni stop pannu. Apram:

```powershell
.venv\Scripts\python.exe app.py create-admin --email admin@example.com --name Administrator
```

Password type pannu. Type pannumbodhu screen-la characters theriyadhu; adhu normal. Confirm password type pannu. Apram `app.py` run panni indha admin email/password-la login pannu.

Admin dashboard-la appointments monitor/cancel pannalam. Appointment start time vandha piragu Complete pannalam. View demand forecast-la model predictions paarkalam.

## Deep learning part

NumPy-la two hidden layers irukkura neural network code serthirukken. Sample data-la train panna model-um irukku. Ippo kaamikura predictions demo mattum; real bank measurements illa. `train_model.py` training code, `predictor.py` prediction code. Details README-la irukku.

## GitHub-la upload panna

ZIP-kulla irukkura `bank-appointment-project` folder-a open pannu. `app.py`, `database.py`, README, requirements, schema files, `templates`, `static`, `data`, `tests`, `docs` folders-a upload pannu. Folder structure maarama irukkanum.

Upload complete aana Commit changes click pannu. Original presentation-only README irundha, indha new README content-oda replace pannu. Ippo repository-la actual source code-um setup steps-um irukkum.

Python commands run panna laptop/PC convenient. GitHub-la upload pannradhu code-a store pannum; Flask application automatic-a live website aagathu. Local-la run panna above steps follow pannu.
