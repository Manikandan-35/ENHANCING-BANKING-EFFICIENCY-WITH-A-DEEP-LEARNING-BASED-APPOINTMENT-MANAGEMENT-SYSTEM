"""Inference for a small two-hidden-layer neural network implemented in NumPy."""
from datetime import date, time as clock_time
from pathlib import Path
import json
import math
import numpy as np

FEATURE_COUNT = 11
TARGET_SCALE = 30.0


def features(day, time, service_id, branch_factor):
    if isinstance(day, str):
        day = date.fromisoformat(day)
    chosen = clock_time.fromisoformat(time)
    if chosen.strftime("%H:%M") != time or not 9 <= chosen.hour < 16 or chosen.minute not in {0, 30}:
        raise ValueError("Time must be a 30-minute slot from 09:00 through 15:30.")
    hour, minute = chosen.hour, chosen.minute
    t = (hour + minute / 60.0 - 9.0) / 7.0
    service = [1.0 if i == int(service_id) - 1 else 0.0 for i in range(4)]
    return np.asarray([
        math.sin(2 * math.pi * day.weekday() / 7),
        math.cos(2 * math.pi * day.weekday() / 7),
        t, t * t, *service, float(branch_factor),
        math.sin(2 * math.pi * day.month / 12),
        math.cos(2 * math.pi * day.month / 12),
    ], dtype=np.float64)


def forward(x, weights):
    h1 = np.maximum(x @ weights["w1"] + weights["b1"], 0)
    h2 = np.maximum(h1 @ weights["w2"] + weights["b2"], 0)
    z = np.clip(h2 @ weights["w3"] + weights["b3"], -30, 30)
    y = 1 / (1 + np.exp(-z))
    return h1, h2, y


class DemandPredictor:
    def __init__(self, model_path):
        path = Path(model_path)
        self.weights = None
        self.metadata = {}
        if path.is_file():
            with np.load(path, allow_pickle=False) as data:
                self.weights = {key: data[key].copy() for key in ("w1", "b1", "w2", "b2", "w3", "b3")}
            if self.weights["w1"].shape[0] != FEATURE_COUNT:
                raise ValueError("Model feature count does not match predictor.py")
            metadata_path = path.with_suffix(".json")
            if metadata_path.is_file():
                self.metadata = json.loads(metadata_path.read_text(encoding="utf-8"))

    @property
    def available(self):
        return self.weights is not None

    def predict(self, day, time, service_id, branch_factor=1.0):
        if not self.available:
            return None
        x = features(day, time, service_id, branch_factor)[None, :]
        prediction = float(forward(x, self.weights)[2][0, 0] * TARGET_SCALE)
        return round(max(0.0, prediction), 1)

    @staticmethod
    def label(prediction):
        if prediction is None:
            return "Unavailable"
        return "Low" if prediction < 7 else ("Moderate" if prediction < 12 else "High")
