"""Small parameterized SQL adapter for SQLite and optional MySQL 8+."""
from contextlib import contextmanager
from pathlib import Path
import os
import sqlite3


class Database:
    def __init__(self, config):
        self.kind = config.get("DB_ENGINE", "sqlite")
        if self.kind == "sqlite":
            path = Path(config["DATABASE_PATH"])
            path.parent.mkdir(parents=True, exist_ok=True)
            self.connection = sqlite3.connect(path, isolation_level=None, timeout=10)
            self.connection.row_factory = sqlite3.Row
            self.connection.execute("PRAGMA foreign_keys=ON")
            self.connection.execute("PRAGMA busy_timeout=10000")
            self.integrity_errors = (sqlite3.IntegrityError,)
        elif self.kind == "mysql":
            try:
                import mysql.connector
            except ImportError as exc:
                raise RuntimeError("Install requirements-mysql.txt to use MySQL.") from exc
            self.connection = mysql.connector.connect(
                host=config.get("MYSQL_HOST", "127.0.0.1"),
                port=int(config.get("MYSQL_PORT", 3306)),
                user=config.get("MYSQL_USER", "bank_app"),
                password=config.get("MYSQL_PASSWORD", ""),
                database=config.get("MYSQL_DATABASE", "bank_appointments"),
                autocommit=True, connection_timeout=10,
                charset="utf8mb4", collation="utf8mb4_unicode_ci",
            )
            self.integrity_errors = (mysql.connector.IntegrityError,)
        else:
            raise ValueError("DB_ENGINE must be sqlite or mysql.")

    def _cursor(self):
        return (self.connection.cursor(dictionary=True) if self.kind == "mysql"
                else self.connection.cursor())

    def _sql(self, sql):
        return sql.replace("?", "%s") if self.kind == "mysql" else sql

    def query(self, sql, params=()):
        cursor = self._cursor()
        try:
            cursor.execute(self._sql(sql), params)
            return [dict(row) for row in cursor.fetchall()]
        finally:
            cursor.close()

    def one(self, sql, params=()):
        rows = self.query(sql, params)
        return rows[0] if rows else None

    def execute(self, sql, params=()):
        cursor = self._cursor()
        try:
            cursor.execute(self._sql(sql), params)
            return cursor.lastrowid, cursor.rowcount
        finally:
            cursor.close()

    @contextmanager
    def transaction(self):
        if self.kind == "mysql":
            self.connection.start_transaction()
        else:
            self.connection.execute("BEGIN IMMEDIATE")
        try:
            yield self
            self.connection.commit()
        except BaseException:
            self.connection.rollback()
            raise

    def initialize(self, root):
        schema = Path(root) / ("schema_mysql.sql" if self.kind == "mysql" else "schema.sql")
        for statement in schema.read_text(encoding="utf-8").split(";"):
            if statement.strip():
                self.execute(statement)
        with self.transaction():
            if not self.one("SELECT id FROM branches LIMIT 1"):
                for name, location, factor in [
                    ("City Centre Branch", "Chennai", 1.0),
                    ("Campus Road Branch", "Tiruchirappalli", 0.75),
                ]:
                    self.execute("INSERT INTO branches (name, location, demand_factor) VALUES (?, ?, ?)",
                                 (name, location, factor))
            if not self.one("SELECT id FROM services LIMIT 1"):
                for name in ["Account Opening", "Loan Enquiry", "Account Services", "Customer Support"]:
                    self.execute("INSERT INTO services (name, duration_minutes) VALUES (?, ?)", (name, 30))

    def close(self):
        self.connection.close()


def config_from_environment(instance_path):
    return {
        "DB_ENGINE": os.getenv("DB_ENGINE", "sqlite").lower(),
        "DATABASE_PATH": os.getenv("DATABASE_PATH", str(Path(instance_path) / "appointments.db")),
        "MYSQL_HOST": os.getenv("MYSQL_HOST", "127.0.0.1"),
        "MYSQL_PORT": os.getenv("MYSQL_PORT", "3306"),
        "MYSQL_USER": os.getenv("MYSQL_USER", "bank_app"),
        "MYSQL_PASSWORD": os.getenv("MYSQL_PASSWORD", ""),
        "MYSQL_DATABASE": os.getenv("MYSQL_DATABASE", "bank_appointments"),
    }
