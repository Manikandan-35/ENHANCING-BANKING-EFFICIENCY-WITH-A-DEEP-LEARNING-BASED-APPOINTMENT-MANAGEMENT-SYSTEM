"""Train a real NumPy neural network on explicitly synthetic or supplied history.

CSV columns: date,time,service_id,branch_factor,customer_count.
"""
from datetime import date, timedelta
from pathlib import Path
import argparse
import csv
import json
import math
import numpy as np
from predictor import FEATURE_COUNT, TARGET_SCALE, features, forward

ROOT = Path(__file__).resolve().parent


def generate_demo_history(path, rows=2200):
    rng = np.random.default_rng(42)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["date", "time", "service_id", "branch_factor", "customer_count"])
        start = date(2025, 1, 1)
        for _ in range(rows):
            day = start + timedelta(days=int(rng.integers(0, 365)))
            if day.weekday() == 6:
                day += timedelta(days=1)
            minute = int(rng.integers(0, 14)) * 30 + 9 * 60
            hour = minute / 60
            service = int(rng.integers(1, 5))
            factor = float(rng.choice([0.75, 1.0]))
            # A toy demand process, not measurements from a real bank.
            peak = 7.5 * math.exp(-((hour - 11.5) / 1.7) ** 2)
            day_effect = [3, 1.5, 1, 1, 2.5, 3.5, 0][day.weekday()]
            service_effect = [0, 1.5, 2.5, 0.5][service - 1]
            expected = (3 + peak + day_effect + service_effect) * factor
            count = max(0, int(round(expected + rng.normal(0, 1.1))))
            writer.writerow([day.isoformat(), f"{minute // 60:02d}:{minute % 60:02d}", service, factor, count])


def load_history(path):
    xs, ys = [], []
    with path.open(newline="", encoding="utf-8") as handle:
        for line, row in enumerate(csv.DictReader(handle), 2):
            try:
                service_id = int(row["service_id"])
                factor = float(row["branch_factor"])
                count = float(row["customer_count"])
                if not 1 <= service_id <= 4 or not 0 < factor <= 2 or not 0 <= count <= TARGET_SCALE:
                    raise ValueError("out-of-range service, factor, or count")
                x = features(row["date"], row["time"], service_id, factor)
                if not np.isfinite(x).all():
                    raise ValueError("non-finite features")
                xs.append(x)
                ys.append(count / TARGET_SCALE)
            except (KeyError, ValueError) as exc:
                raise ValueError(f"Invalid CSV row {line}: {exc}") from exc
    if len(xs) < 50:
        raise ValueError("Provide at least 50 historical rows.")
    return np.asarray(xs), np.asarray(ys)[:, None]


def train(data_path, output, epochs=500, synthetic=False):
    x, y = load_history(data_path)
    rng = np.random.default_rng(7)
    order = rng.permutation(len(x))
    split = int(0.8 * len(x))
    xt, yt = x[order[:split]], y[order[:split]]
    xv, yv = x[order[split:]], y[order[split:]]
    weights = {
        "w1": rng.normal(0, np.sqrt(2 / FEATURE_COUNT), (FEATURE_COUNT, 24)),
        "b1": np.zeros((1, 24)),
        "w2": rng.normal(0, np.sqrt(2 / 24), (24, 12)), "b2": np.zeros((1, 12)),
        "w3": rng.normal(0, np.sqrt(2 / 12), (12, 1)), "b3": np.zeros((1, 1)),
    }
    first = {k: np.zeros_like(v) for k, v in weights.items()}
    second = {k: np.zeros_like(v) for k, v in weights.items()}
    for step in range(1, epochs + 1):
        h1, h2, pred = forward(xt, weights)
        dz3 = (2 / len(xt)) * (pred - yt) * pred * (1 - pred)
        dz2 = (dz3 @ weights["w3"].T) * (h2 > 0)
        dz1 = (dz2 @ weights["w2"].T) * (h1 > 0)
        grads = {
            "w3": h2.T @ dz3, "b3": dz3.sum(axis=0, keepdims=True),
            "w2": h1.T @ dz2, "b2": dz2.sum(axis=0, keepdims=True),
            "w1": xt.T @ dz1, "b1": dz1.sum(axis=0, keepdims=True),
        }
        for k in weights:
            first[k] = 0.9 * first[k] + 0.1 * grads[k]
            second[k] = 0.999 * second[k] + 0.001 * grads[k] ** 2
            weights[k] -= 0.008 * (first[k] / (1 - 0.9 ** step)) / (
                np.sqrt(second[k] / (1 - 0.999 ** step)) + 1e-8)
    predictions = forward(xv, weights)[2] * TARGET_SCALE
    actual = yv * TARGET_SCALE
    metadata = {
        "architecture": [FEATURE_COUNT, 24, 12, 1], "hidden_activation": "ReLU",
        "output_activation": "sigmoid", "optimizer": "Adam", "epochs": epochs,
        "training_rows": len(xt), "validation_rows": len(xv),
        "validation_mae": round(float(np.abs(predictions - actual).mean()), 3),
        "validation_rmse": round(float(np.sqrt(((predictions - actual) ** 2).mean())), 3),
        "data_source": "synthetic_demo" if synthetic else "user_supplied",
        "split": "deterministic random 80/20; not a prospective time-series evaluation",
        "target": "customers per 30-minute service slot",
        "note": "Demo results do not establish accuracy for real bank operations.",
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(output, **weights)
    output.with_suffix(".json").write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
    return metadata


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path)
    parser.add_argument("--output", type=Path, default=ROOT / "data" / "demand_model.npz")
    parser.add_argument("--epochs", type=int, default=500)
    args = parser.parse_args()
    if not 1 <= args.epochs <= 10000:
        parser.error("epochs must be between 1 and 10000")
    synthetic = args.data is None
    path = args.data or ROOT / "data" / "demo_history.csv"
    if synthetic:
        generate_demo_history(path)
    print(json.dumps(train(path, args.output, args.epochs, synthetic), indent=2))
