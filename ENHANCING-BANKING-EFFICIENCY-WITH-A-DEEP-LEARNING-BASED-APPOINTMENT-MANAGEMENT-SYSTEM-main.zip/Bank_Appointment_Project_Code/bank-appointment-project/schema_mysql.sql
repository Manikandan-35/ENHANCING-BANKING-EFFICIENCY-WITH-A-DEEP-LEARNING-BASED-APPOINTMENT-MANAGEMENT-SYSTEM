CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(80) NOT NULL,
    email VARCHAR(254) NOT NULL UNIQUE,
    password_hash VARCHAR(512) NOT NULL,
    role VARCHAR(16) NOT NULL DEFAULT 'customer',
    created_at VARCHAR(32) NOT NULL,
    CHECK (role IN ('customer', 'admin'))
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS branches (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL UNIQUE,
    location VARCHAR(100) NOT NULL,
    demand_factor DOUBLE NOT NULL DEFAULT 1.0
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS services (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL UNIQUE,
    duration_minutes INT NOT NULL DEFAULT 30
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS appointments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    branch_id INT NOT NULL,
    service_id INT NOT NULL,
    appointment_date VARCHAR(10) NOT NULL,
    appointment_time VARCHAR(5) NOT NULL,
    status VARCHAR(16) NOT NULL DEFAULT 'booked',
    active_slot_key VARCHAR(120) UNIQUE,
    notes VARCHAR(500) NOT NULL DEFAULT '',
    created_at VARCHAR(32) NOT NULL,
    updated_at VARCHAR(32) NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (branch_id) REFERENCES branches(id),
    FOREIGN KEY (service_id) REFERENCES services(id),
    CHECK (status IN ('booked', 'cancelled', 'completed')),
    INDEX idx_appointments_user (user_id),
    INDEX idx_appointments_date (appointment_date, status)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS audit_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    actor_id INT,
    appointment_id INT,
    action VARCHAR(50) NOT NULL,
    details VARCHAR(500) NOT NULL DEFAULT '',
    created_at VARCHAR(32) NOT NULL,
    FOREIGN KEY (actor_id) REFERENCES users(id),
    FOREIGN KEY (appointment_id) REFERENCES appointments(id)
) ENGINE=InnoDB;
