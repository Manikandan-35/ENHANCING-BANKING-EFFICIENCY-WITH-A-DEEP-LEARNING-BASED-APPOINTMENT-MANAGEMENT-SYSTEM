"use strict";

document.querySelectorAll("form[data-confirm]").forEach((form) => {
  form.addEventListener("submit", (event) => {
    if (!window.confirm(form.dataset.confirm)) event.preventDefault();
  });
});

const booking = document.querySelector("#booking-form");
if (booking) {
  const branch = document.querySelector("#branch-id");
  const service = document.querySelector("#service-id");
  const day = document.querySelector("#appointment-date");
  const timeSelect = document.querySelector("#appointment-time");
  const grid = document.querySelector("#slot-grid");
  const message = document.querySelector("#slot-message");
  const submit = document.querySelector("#booking-submit");
  let sequence = 0;
  let initial = true;

  function syncSelection() {
    grid.querySelectorAll("button").forEach((button) => {
      const selected = button.dataset.time === timeSelect.value;
      button.classList.toggle("selected", selected);
      button.setAttribute("aria-pressed", String(selected));
    });
    submit.disabled = !timeSelect.value;
  }

  async function loadSlots() {
    const version = ++sequence;
    const oldTime = initial ? booking.dataset.selectedTime : timeSelect.value;
    initial = false;
    submit.disabled = true;
    message.textContent = "Checking time slots…";
    grid.replaceChildren();
    timeSelect.replaceChildren(new Option("Select a time", ""));
    const query = new URLSearchParams({branch_id: branch.value, service_id: service.value, date: day.value});
    if (booking.dataset.excludeId) query.set("exclude_id", booking.dataset.excludeId);
    try {
      const response = await fetch(`${booking.dataset.slotUrl}?${query}`);
      const data = await response.json();
      if (version !== sequence) return;
      if (!response.ok) throw new Error(data.error || "Availability could not be loaded.");
      let available = 0;
      data.slots.forEach((slot) => {
        if (slot.available) {
          timeSelect.add(new Option(`${slot.time} · ${slot.demand_label} demand`, slot.time));
          available++;
        }
        const button = document.createElement("button");
        button.type = "button";
        button.className = `slot-button ${slot.available ? "" : "unavailable"}`;
        button.disabled = !slot.available;
        button.dataset.time = slot.time;
        const title = document.createElement("strong");
        title.textContent = slot.time;
        const label = document.createElement("span");
        label.textContent = slot.available ? `${slot.demand_label} demand` : "Unavailable";
        button.append(title, label);
        button.addEventListener("click", () => { timeSelect.value = slot.time; syncSelection(); });
        grid.append(button);
      });
      if ([...timeSelect.options].some((option) => option.value === oldTime)) timeSelect.value = oldTime;
      message.textContent = available ? `${available} slots available. All times are in IST.` : "No available slots for this date. Choose another day.";
      syncSelection();
    } catch (error) {
      if (version !== sequence) return;
      message.textContent = error instanceof SyntaxError ? "Please sign in again or reload this page." : error.message;
    }
  }
  [branch, service, day].forEach((field) => field.addEventListener("change", loadSlots));
  timeSelect.addEventListener("change", syncSelection);
  loadSlots();
}

const forecast = document.querySelector("#forecast-form");
if (forecast) {
  let version = 0;
  const message = document.querySelector("#forecast-message");
  const body = document.querySelector("#forecast-body");
  async function updateForecast(event) {
    if (event) event.preventDefault();
    const current = ++version;
    message.textContent = "Loading forecast…";
    body.replaceChildren();
    const query = new URLSearchParams({
      branch_id: document.querySelector("#forecast-branch").value,
      service_id: document.querySelector("#forecast-service").value,
      date: document.querySelector("#forecast-date").value,
    });
    try {
      const response = await fetch(`${forecast.dataset.slotUrl}?${query}`);
      const data = await response.json();
      if (current !== version) return;
      if (!response.ok) throw new Error(data.error || "Unable to load forecast.");
      data.slots.forEach((slot) => {
        const row = document.createElement("tr");
        const values = [slot.time, slot.demand === null ? "Unavailable" : slot.demand.toFixed(1), slot.demand_label, slot.available ? "Available" : "Unavailable"];
        values.forEach((value) => { const cell = document.createElement("td"); cell.textContent = value; row.append(cell); });
        body.append(row);
      });
      message.textContent = data.data_source === "synthetic_demo" ? "Forecast from generated sample data. Customer counts are estimates, not live queue measurements." : "Customer counts are model estimates.";
    } catch (error) {
      if (current === version) message.textContent = error.message;
    }
  }
  forecast.addEventListener("submit", updateForecast);
  updateForecast();
}
