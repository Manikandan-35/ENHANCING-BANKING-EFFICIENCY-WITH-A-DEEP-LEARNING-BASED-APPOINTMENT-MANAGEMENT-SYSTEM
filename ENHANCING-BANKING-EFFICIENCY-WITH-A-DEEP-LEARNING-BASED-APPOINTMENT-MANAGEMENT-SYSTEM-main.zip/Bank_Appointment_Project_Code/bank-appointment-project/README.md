# Bank Appointment Management System

**Academic topic:** Enhancing Banking Efficiency with a Deep Learning-Based Appointment Management System

A runnable academic project based on the supplied presentation. Customers can register, log in, book a bank visit, reschedule it, cancel it, and view appointment history. Administrators can monitor appointments, cancel bookings, mark attended appointments as completed, inspect recent activity, and explore a demand forecast.

The app uses Python, Flask, HTML, CSS, JavaScript, and a database. SQLite is the default for an easy local setup. An optional MySQL adapter and schema are included. The demand model is a real two-hidden-layer neural network implemented with NumPy, trained on **generated demonstration data**. Its forecasts are not evidence of real bank demand or waiting-time reduction.

## Quick start on Windows

Install Python 3.10 or newer. Extract the ZIP, open the `bank-appointment-project` folder in VS Code, and open its terminal.

```powershell
py -3 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe app.py
```

Open **http://127.0.0.1:5000** in your browser. The database and example branches/services are created automatically. Register your own customer account, sign in, and book an available future slot. No default password or customer account is shipped.

To stop the application, press `Ctrl+C` in the terminal.

## Quick start on macOS / Linux

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python app.py
```

Open **http://127.0.0.1:5000**.

## Create an administrator

Stop the running app, then run:

```powershell
.venv\Scripts\python.exe app.py create-admin --email admin@example.com --name Administrator
```

Enter and confirm a password of at least 8 characters when prompted. Password input is hidden. Start the application again and sign in with the administrator account. For macOS/Linux, replace `.venv\Scripts\python.exe` with `.venv/bin/python`.

The administrator role is created through this local command. Public registration always creates a customer account.

## Implemented modules

| Module | Behavior |
| --- | --- |
| Register | Validate name, email, and password; reject duplicate emails; store password hashes. |
| Log in / Log out | Authenticate accounts, rotate session state on login, and end sessions on logout. |
| Book appointment | Select branch, service, date, and time; confirm availability on the server. |
| Modify appointment | Change service, branch, date, time, or notes while retaining the old booking if the new slot is occupied. |
| Cancel appointment | Record cancellation and release the reserved slot. |
| Customer dashboard | View upcoming visits and appointment history. |
| Admin dashboard | Filter appointments by date/status, cancel bookings, complete visits after their start time, and inspect recent audit events. |
| Demand forecast | Run neural-network inference for each time slot and show sample-data demand labels. |

Business hours are Monday to Saturday, 09:00–16:00 IST, with 30-minute slots; the final start time is 15:30. Customers can book up to 60 days ahead. Sundays and elapsed slots are unavailable. Capacity is **one active appointment per branch, service, date, and time**.

A unique database reservation key prevents duplicate booking, including concurrent requests. Cancellation/completion clears that key. Appointment modification and audit events use transactions.

## Neural network demo

Included files:

- `predictor.py`: feature encoding and inference.
- `train_model.py`: synthetic-history generation, backpropagation, and Adam optimization.
- `data/demo_history.csv`: explicitly generated toy historical counts.
- `data/demand_model.npz`: trained numerical weights; loaded without pickle.
- `data/demand_model.json`: model architecture, data provenance, and validation metrics.

Architecture: **11 input features → 24 ReLU units → 12 ReLU units → 1 sigmoid output**. Features encode weekday, time, service category, branch demand factor, and month. The output estimates customer count per 30-minute slot on a 0–30 scale. Labels use fixed thresholds: Low `<7`, Moderate `7–<12`, High `≥12`.

Retrain the included demo:

```powershell
.venv\Scripts\python.exe train_model.py
```

Train from your own properly prepared history:

```powershell
.venv\Scripts\python.exe train_model.py --data path\to\history.csv --epochs 500
```

CSV columns must be `date,time,service_id,branch_factor,customer_count`. Dates use `YYYY-MM-DD`, times use `HH:MM`, service IDs are 1–4, branch factor is greater than 0 and at most 2, and customer counts are 0–30. Provide at least 50 rows. Restart the app after retraining so it loads the new weights.

The bundled metrics come from a deterministic random 80/20 split of synthetic data. They do not measure prospective forecasting performance. Real deployment would require representative historical data, a chronological evaluation, capacity calibration, and operational validation. The application does not perform bank transactions. OTP, email/SMS notifications, staff roster optimization, and real-time external queue integration are not implemented; the PPT discusses a broader proposal.

## Optional MySQL setup

SQLite needs no separate server. To use MySQL, install MySQL 8+ and the optional dependency:

```powershell
.venv\Scripts\python.exe -m pip install -r requirements-mysql.txt
```

Using an account allowed to create databases and users, run these commands in MySQL. Replace the example password before using it:

```sql
CREATE DATABASE bank_appointments CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'bank_app'@'127.0.0.1' IDENTIFIED BY 'REPLACE_WITH_YOUR_PASSWORD';
GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, INDEX, REFERENCES
ON bank_appointments.* TO 'bank_app'@'127.0.0.1';
```

Then set the environment variables in the same PowerShell terminal:

```powershell
$env:DB_ENGINE="mysql"
$env:MYSQL_HOST="127.0.0.1"
$env:MYSQL_PORT="3306"
$env:MYSQL_USER="bank_app"
$env:MYSQL_DATABASE="bank_appointments"
$env:MYSQL_PASSWORD="YOUR_DATABASE_PASSWORD"
.venv\Scripts\python.exe app.py init-db
.venv\Scripts\python.exe app.py create-admin --email admin@example.com
.venv\Scripts\python.exe app.py
```

For macOS/Linux, set the same variables with `export VARIABLE=value`. Tables are initialized from `schema_mysql.sql`; the database itself must exist beforehand. Data is not automatically migrated from SQLite. Do not put the real database password in source files or commit terminal scripts containing it.

## Tests

```powershell
.venv\Scripts\python.exe -m unittest discover -s tests -v
```

Tests use temporary SQLite databases. They check customer journeys, conflicting and concurrent bookings, atomic rescheduling, cancellation/rebooking, customer ownership, admin permissions, completion timing, CSRF protection, escaping, model input validation, and the included model. All 15 tests passed during this build. The customer booking journey, admin forecast page, and mobile layout were also checked in a browser without JavaScript errors. The optional MySQL adapter has not been tested against a live MySQL server in this build.

## Upload to GitHub

1. Extract `Bank_Appointment_Project_Code.zip`.
2. Open the `bank-appointment-project` folder.
3. Upload its **files and subfolders**, preserving the structure. Upload the `templates`, `static`, `data`, `tests`, and `docs` folders too.
4. Put this `README.md` at the repository root so the setup guide appears on the repository homepage.
5. Commit the files and copy the repository URL for your resume.

Upload the extracted contents to make the code directly browsable. Keep `.venv`, `instance`, databases, private keys, real customer records, and passwords out of the repository. The included `.gitignore` covers local runtime artifacts when you use Git.

## Folder guide

| Path | Purpose |
| --- | --- |
| `app.py` | HTTP routes, validation, authorization, and booking logic. |
| `database.py` | Parameterized SQLite/MySQL database access. |
| `schema.sql`, `schema_mysql.sql` | Database tables and constraints. |
| `templates/` | HTML pages. |
| `static/` | CSS and JavaScript. |
| `data/` | Demo model, metadata, and generated training data. |
| `tests/` | Integration and model tests. |
| `docs/Bank_Appointment_Project.pptx` | Original project presentation. |
| `requirements.txt` | Dependencies for the default SQLite app. |

## Configuration

`PORT` changes the local port (default 5000). `SECRET_KEY` can supply a session signing key; otherwise a random key is created locally under `instance/`. `DATABASE_PATH` selects the SQLite file. `COOKIE_SECURE=1` is for an HTTPS setup, not the default local HTTP address.

The included server is for local development and demonstration. A public service needs a production WSGI server, HTTPS, rate limiting, monitoring, backup/recovery, and a review of data handling before accepting real customer records.

## Project credits

Presentation team: **P. Athithya (CB2308), M. Manikandan (CB2335), M. Riyash (CB2345)**.

Guide: **Mrs. N. G. Gayathri, M.E., Assistant Professor, CSBS**.

This source implementation was newly generated with AI assistance from the project presentation. Review it, run it, and understand the code before presenting it as your work.

## Reference documentation

- [Flask quickstart](https://flask.palletsprojects.com/en/stable/quickstart/)
- [Flask application testing](https://flask.palletsprojects.com/en/stable/testing/)
- [Flask web security](https://flask.palletsprojects.com/en/stable/web-security/)
- [Python sqlite3](https://docs.python.org/3/library/sqlite3.html)
- [MySQL Connector/Python](https://dev.mysql.com/doc/connector-python/en/connector-python-connectargs.html)
- [NumPy numerical array loading](https://numpy.org/doc/stable/reference/generated/numpy.load.html)
