"""Bank appointment project: Flask views, validation, and transaction-safe bookings."""
from datetime import date, datetime, timedelta
from functools import wraps
from pathlib import Path
from zoneinfo import ZoneInfo
import argparse
import getpass
import hmac
import os
import re
import secrets

from flask import Flask, abort, flash, g, jsonify, redirect, render_template, request, session, url_for
from werkzeug.exceptions import HTTPException
from werkzeug.security import check_password_hash, generate_password_hash

from database import Database, config_from_environment
from predictor import DemandPredictor

ROOT = Path(__file__).resolve().parent
TIMEZONE = ZoneInfo("Asia/Kolkata")
TIMES = tuple(f"{m // 60:02d}:{m % 60:02d}" for m in range(9 * 60, 16 * 60, 30))
EMAIL_PATTERN = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")


def now():
    return datetime.now(TIMEZONE)


def stamp():
    return now().isoformat(timespec="seconds")


def get_db():
    if "db" not in g:
        from flask import current_app
        g.db = Database(current_app.config)
    return g.db


def csrf_token():
    if "csrf_token" not in session:
        session["csrf_token"] = secrets.token_urlsafe(32)
    return session["csrf_token"]


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if g.user is None:
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


def admin_required(view):
    @wraps(view)
    @login_required
    def wrapped(*args, **kwargs):
        if g.user["role"] != "admin":
            abort(403, description="This page is only available to administrators.")
        return view(*args, **kwargs)
    return wrapped


def audit(action, appointment_id=None, details="", actor_id=None):
    get_db().execute(
        "INSERT INTO audit_logs (actor_id, appointment_id, action, details, created_at) VALUES (?, ?, ?, ?, ?)",
        (actor_id if actor_id is not None else (g.user["id"] if g.user else None),
         appointment_id, action, details[:500], stamp()))


def valid_account(name, email, password):
    if not 2 <= len(name) <= 80 or any(ord(c) < 32 for c in name):
        return "Enter a name between 2 and 80 characters."
    if not EMAIL_PATTERN.fullmatch(email) or len(email) > 254:
        return "Enter a valid email address."
    if not 8 <= len(password) <= 128:
        return "Use a password between 8 and 128 characters."
    return None


def valid_day(value):
    try:
        chosen = date.fromisoformat(value)
        if chosen.isoformat() != value:
            raise ValueError
    except (ValueError, TypeError):
        raise ValueError("Choose a valid date.") from None
    if not now().date() <= chosen <= now().date() + timedelta(days=60):
        raise ValueError("Choose a date from today through the next 60 days.")
    if chosen.weekday() == 6:
        raise ValueError("Branches are closed on Sundays.")
    return chosen


def catalogs():
    db = get_db()
    return db.query("SELECT * FROM branches ORDER BY id"), db.query("SELECT * FROM services ORDER BY id")


def slot_key(branch_id, service_id, day, time):
    return f"{branch_id}:{service_id}:{day}:{time}"


def booking_values(form):
    try:
        branch_id, service_id = int(form.get("branch_id", "")), int(form.get("service_id", ""))
    except (ValueError, TypeError):
        raise ValueError("Choose a branch and a service.") from None
    db = get_db()
    if not db.one("SELECT id FROM branches WHERE id=?", (branch_id,)) or not db.one(
            "SELECT id FROM services WHERE id=?", (service_id,)):
        raise ValueError("Choose an existing branch and service.")
    day = valid_day(form.get("appointment_date", ""))
    time = form.get("appointment_time", "")
    if time not in TIMES:
        raise ValueError("Choose a valid 30-minute slot between 09:00 and 15:30.")
    selected = datetime.fromisoformat(f"{day.isoformat()}T{time}").replace(tzinfo=TIMEZONE)
    if selected <= now():
        raise ValueError("Choose a future time slot.")
    notes = form.get("notes", "").strip()
    if len(notes) > 500:
        raise ValueError("Notes must be no longer than 500 characters.")
    return branch_id, service_id, day.isoformat(), time, notes


def appointment_or_404(appointment_id):
    row = get_db().one("""SELECT a.*, b.name AS branch_name, s.name AS service_name,
                          u.name AS customer_name, u.email AS customer_email
                          FROM appointments a JOIN branches b ON b.id=a.branch_id
                          JOIN services s ON s.id=a.service_id JOIN users u ON u.id=a.user_id
                          WHERE a.id=?""", (appointment_id,))
    if not row:
        abort(404, description="Appointment not found.")
    if g.user["role"] != "admin" and row["user_id"] != g.user["id"]:
        abort(403, description="You can only access your own appointments.")
    return row


def create_app(test_config=None):
    app = Flask(__name__, instance_path=str(ROOT / "instance"))
    app.config.update(config_from_environment(app.instance_path))
    app.config.update(
        SECRET_KEY=os.getenv("SECRET_KEY"), MAX_CONTENT_LENGTH=64 * 1024,
        SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=os.getenv("COOKIE_SECURE", "0") == "1",
        PERMANENT_SESSION_LIFETIME=timedelta(hours=8),
        MODEL_PATH=str(ROOT / "data" / "demand_model.npz"),
    )
    if test_config:
        app.config.update(test_config)
    if not app.config["SECRET_KEY"]:
        secret_path = Path(app.instance_path) / ".secret_key"
        secret_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            with secret_path.open("x", encoding="utf-8") as handle:
                handle.write(secrets.token_hex(32))
            secret_path.chmod(0o600)
        except FileExistsError:
            pass
        app.config["SECRET_KEY"] = secret_path.read_text(encoding="utf-8").strip()
    app.extensions["demand_predictor"] = DemandPredictor(app.config["MODEL_PATH"])
    database = Database(app.config)
    try:
        database.initialize(ROOT)
    finally:
        database.close()

    @app.before_request
    def load_user_and_validate_csrf():
        g.user = None
        if session.get("user_id") is not None:
            g.user = get_db().one("SELECT id, name, email, role FROM users WHERE id=?", (session["user_id"],))
            if not g.user:
                session.clear()
        if request.method in {"POST", "PUT", "PATCH", "DELETE"}:
            expected = session.get("csrf_token", "")
            supplied = request.form.get("csrf_token", "")
            if not expected or not hmac.compare_digest(expected, supplied):
                abort(400, description="This form has expired. Reload the page and try again.")

    @app.teardown_appcontext
    def close_database(_error):
        db = g.pop("db", None)
        if db is not None:
            db.close()

    @app.context_processor
    def helpers():
        return {"csrf_token": csrf_token, "current_user": g.get("user"), "booking_times": TIMES,
                "today": now().date().isoformat(),
                "max_date": (now().date() + timedelta(days=60)).isoformat(),
                "forecast_source": app.extensions["demand_predictor"].metadata.get("data_source", "unknown")}

    @app.after_request
    def response_headers(response):
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "same-origin"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
            "frame-ancestors 'none'; form-action 'self'; base-uri 'self'")
        if g.get("user"):
            response.headers["Cache-Control"] = "no-store"
        return response

    @app.errorhandler(HTTPException)
    def http_error(error):
        if request.path.startswith("/api/"):
            return jsonify(error=error.description), error.code
        return render_template("error.html", error=error), error.code

    @app.get("/")
    def home():
        return render_template("home.html")

    @app.route("/register", methods=["GET", "POST"])
    def register():
        error = None
        values = request.form if request.method == "POST" else {}
        if request.method == "POST":
            name = request.form.get("name", "").strip()
            email = request.form.get("email", "").strip().lower()
            password = request.form.get("password", "")
            error = valid_account(name, email, password)
            if not error and password != request.form.get("confirm_password", ""):
                error = "The passwords do not match."
            if not error:
                db = get_db()
                try:
                    with db.transaction():
                        user_id, _ = db.execute("""INSERT INTO users
                            (name, email, password_hash, role, created_at) VALUES (?, ?, ?, 'customer', ?)""",
                            (name, email, generate_password_hash(password), stamp()))
                        audit("register", actor_id=user_id)
                except db.integrity_errors:
                    error = "An account already exists for this email address."
                else:
                    flash("Account created. You can now sign in.", "success")
                    return redirect(url_for("login"), code=303)
        return render_template("auth.html", mode="register", error=error, values=values), (400 if error else 200)

    @app.route("/login", methods=["GET", "POST"])
    def login():
        error = None
        if request.method == "POST":
            email = request.form.get("email", "").strip().lower()
            password = request.form.get("password", "")
            user = get_db().one("SELECT * FROM users WHERE email=?", (email,))
            if not user or len(password) > 128 or not check_password_hash(user["password_hash"], password):
                error = "The email address or password is incorrect."
            else:
                session.clear()
                session["user_id"] = user["id"]
                session.permanent = True
                csrf_token()
                audit("login", actor_id=user["id"])
                return redirect(url_for("admin" if user["role"] == "admin" else "dashboard"), code=303)
        return render_template("auth.html", mode="login", error=error, values=request.form), (400 if error else 200)

    @app.post("/logout")
    @login_required
    def logout():
        audit("logout")
        session.clear()
        flash("You have signed out.", "success")
        return redirect(url_for("home"), code=303)

    @app.get("/dashboard")
    @login_required
    def dashboard():
        rows = get_db().query("""SELECT a.*, b.name AS branch_name, s.name AS service_name
            FROM appointments a JOIN branches b ON b.id=a.branch_id
            JOIN services s ON s.id=a.service_id WHERE a.user_id=?
            ORDER BY a.appointment_date DESC, a.appointment_time DESC, a.id DESC""", (g.user["id"],))
        current = now().strftime("%Y-%m-%d %H:%M")
        for row in rows:
            row["upcoming"] = row["status"] == "booked" and f"{row['appointment_date']} {row['appointment_time']}" > current
        upcoming = sorted((r for r in rows if r["upcoming"]), key=lambda r: (r["appointment_date"], r["appointment_time"]))
        return render_template("dashboard.html", appointments=rows, upcoming=upcoming,
                               scheduled=sum(r["upcoming"] for r in rows),
                               cancelled=sum(r["status"] == "cancelled" for r in rows))

    def booking_page(existing=None, error=None, status=200):
        branches, services = catalogs()
        values = dict(request.form) if request.method == "POST" else dict(existing or {})
        day = now().date()
        if day.weekday() == 6:
            day += timedelta(days=1)
        values.setdefault("appointment_date", day.isoformat())
        values.setdefault("branch_id", branches[0]["id"])
        values.setdefault("service_id", services[0]["id"])
        return render_template("booking.html", values=values, branches=branches, services=services,
                               existing=existing, error=error), status

    @app.route("/appointments/new", methods=["GET", "POST"])
    @login_required
    def book():
        if request.method == "POST":
            try:
                branch, service, day, time, notes = booking_values(request.form)
            except ValueError as error:
                return booking_page(error=str(error), status=400)
            db = get_db()
            try:
                with db.transaction():
                    appointment_id, _ = db.execute("""INSERT INTO appointments
                        (user_id, branch_id, service_id, appointment_date, appointment_time, active_slot_key,
                         notes, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                        (g.user["id"], branch, service, day, time, slot_key(branch, service, day, time), notes, stamp(), stamp()))
                    audit("book", appointment_id)
            except db.integrity_errors:
                return booking_page(error="That slot has just been booked. Please choose another time.", status=409)
            flash(f"Appointment #{appointment_id} booked for {day} at {time} IST.", "success")
            return redirect(url_for("dashboard"), code=303)
        return booking_page()

    @app.route("/appointments/<int:appointment_id>/edit", methods=["GET", "POST"])
    @login_required
    def edit(appointment_id):
        existing = appointment_or_404(appointment_id)
        if existing["status"] != "booked":
            abort(409, description="Only scheduled appointments can be modified.")
        if f"{existing['appointment_date']} {existing['appointment_time']}" <= now().strftime("%Y-%m-%d %H:%M"):
            abort(409, description="Past appointments cannot be rescheduled.")
        if request.method == "POST":
            try:
                branch, service, day, time, notes = booking_values(request.form)
            except ValueError as error:
                return booking_page(existing, str(error), 400)
            db = get_db()
            try:
                with db.transaction():
                    # Status predicate prevents a concurrent cancellation from being overwritten.
                    _, changed = db.execute("""UPDATE appointments SET branch_id=?, service_id=?,
                        appointment_date=?, appointment_time=?, active_slot_key=?, notes=?, updated_at=?
                        WHERE id=? AND status='booked'""",
                        (branch, service, day, time, slot_key(branch, service, day, time), notes, stamp(), appointment_id))
                    if not changed and db.kind == "sqlite":
                        abort(409, description="This appointment changed. Reload the page.")
                    if db.kind == "mysql" and not db.one(
                            "SELECT id FROM appointments WHERE id=? AND status='booked'", (appointment_id,)):
                        abort(409, description="This appointment changed. Reload the page.")
                    audit("modify", appointment_id)
            except db.integrity_errors:
                return booking_page(existing, "The new slot is occupied. Your previous appointment is unchanged.", 409)
            flash("Appointment updated.", "success")
            return redirect(url_for("admin" if g.user["role"] == "admin" else "dashboard"), code=303)
        return booking_page(existing)

    @app.post("/appointments/<int:appointment_id>/cancel")
    @login_required
    def cancel(appointment_id):
        appointment_or_404(appointment_id)
        db = get_db()
        with db.transaction():
            _, changed = db.execute("""UPDATE appointments SET status='cancelled', active_slot_key=NULL,
                updated_at=? WHERE id=? AND status='booked'""", (stamp(), appointment_id))
            if not changed:
                abort(409, description="This appointment is already cancelled or completed.")
            audit("cancel", appointment_id)
        flash("Appointment cancelled. The time slot is available again.", "success")
        return redirect(url_for("admin" if g.user["role"] == "admin" else "dashboard"), code=303)

    @app.get("/api/slots")
    @login_required
    def slots():
        try:
            day = valid_day(request.args.get("date", ""))
            branch_id, service_id = int(request.args.get("branch_id", "")), int(request.args.get("service_id", ""))
        except (ValueError, TypeError) as error:
            abort(400, description=str(error) or "Choose a branch and service.")
        branch = get_db().one("SELECT * FROM branches WHERE id=?", (branch_id,))
        if not branch or not get_db().one("SELECT id FROM services WHERE id=?", (service_id,)):
            abort(400, description="Choose an existing branch and service.")
        exclude_id = request.args.get("exclude_id", type=int)
        if exclude_id is not None:
            appointment_or_404(exclude_id)
        occupied = {r["appointment_time"] for r in get_db().query("""SELECT appointment_time FROM appointments
            WHERE branch_id=? AND service_id=? AND appointment_date=? AND status='booked' AND id<>?""",
            (branch_id, service_id, day.isoformat(), exclude_id or 0))}
        predictor = app.extensions["demand_predictor"]
        result = []
        for time in TIMES:
            future = datetime.fromisoformat(f"{day}T{time}").replace(tzinfo=TIMEZONE) > now()
            prediction = predictor.predict(day, time, service_id, branch["demand_factor"])
            result.append({"time": time, "available": future and time not in occupied,
                           "demand": prediction, "demand_label": predictor.label(prediction)})
        return jsonify(slots=result, data_source=predictor.metadata.get("data_source", "unknown"))

    @app.get("/admin")
    @admin_required
    def admin():
        filters, params = [], []
        chosen_date = request.args.get("date", "")
        chosen_status = request.args.get("status", "")
        if chosen_date:
            try:
                date.fromisoformat(chosen_date)
            except ValueError:
                abort(400, description="Invalid date filter.")
            filters.append("a.appointment_date=?")
            params.append(chosen_date)
        if chosen_status:
            if chosen_status not in {"booked", "cancelled", "completed"}:
                abort(400, description="Invalid status filter.")
            filters.append("a.status=?")
            params.append(chosen_status)
        where = " WHERE " + " AND ".join(filters) if filters else ""
        rows = get_db().query("""SELECT a.*, b.name AS branch_name, s.name AS service_name,
            u.name AS customer_name, u.email AS customer_email FROM appointments a
            JOIN branches b ON b.id=a.branch_id JOIN services s ON s.id=a.service_id
            JOIN users u ON u.id=a.user_id""" + where + " ORDER BY a.appointment_date DESC, a.appointment_time DESC", params)
        current_time = now().strftime("%Y-%m-%d %H:%M")
        for row in rows:
            row["can_complete"] = f"{row['appointment_date']} {row['appointment_time']}" <= current_time
        stats = {r["status"]: r["total"] for r in get_db().query(
            "SELECT status, COUNT(*) AS total FROM appointments GROUP BY status")}
        logs = get_db().query("""SELECT l.*, u.name AS actor_name FROM audit_logs l
            LEFT JOIN users u ON u.id=l.actor_id ORDER BY l.id DESC LIMIT 15""")
        return render_template("admin.html", appointments=rows, stats=stats, logs=logs,
                               chosen_date=chosen_date, chosen_status=chosen_status)

    @app.post("/admin/appointments/<int:appointment_id>/complete")
    @admin_required
    def complete(appointment_id):
        appointment_or_404(appointment_id)
        db = get_db()
        with db.transaction():
            lock = " FOR UPDATE" if db.kind == "mysql" else ""
            existing = db.one("SELECT * FROM appointments WHERE id=?" + lock, (appointment_id,))
            if f"{existing['appointment_date']} {existing['appointment_time']}" > now().strftime("%Y-%m-%d %H:%M"):
                abort(409, description="An appointment can be completed only once its start time has arrived.")
            _, changed = db.execute("""UPDATE appointments SET status='completed', active_slot_key=NULL,
                updated_at=? WHERE id=? AND status='booked'""", (stamp(), appointment_id))
            if not changed:
                abort(409, description="Only scheduled appointments can be completed.")
            audit("complete", appointment_id)
        flash("Appointment marked as completed.", "success")
        return redirect(url_for("admin"), code=303)

    @app.get("/admin/forecast")
    @admin_required
    def forecast():
        branches, services = catalogs()
        return render_template("forecast.html", branches=branches, services=services,
                               model=app.extensions["demand_predictor"].metadata,
                               model_available=app.extensions["demand_predictor"].available)

    return app


def create_admin(app, email, name):
    email, name = email.strip().lower(), name.strip()
    password = getpass.getpass("Admin password (8+ characters): ")
    if password != getpass.getpass("Confirm password: "):
        raise ValueError("Passwords do not match.")
    error = valid_account(name, email, password)
    if error:
        raise ValueError(error)
    db = Database(app.config)
    try:
        if db.one("SELECT id FROM users WHERE email=?", (email,)):
            raise ValueError("This email already exists. Choose another admin email.")
        db.execute("INSERT INTO users (name, email, password_hash, role, created_at) VALUES (?, ?, ?, 'admin', ?)",
                   (name, email, generate_password_hash(password), stamp()))
    finally:
        db.close()
    print("Admin account created. Sign in through the normal login page.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", nargs="?", choices=["run", "init-db", "create-admin"], default="run")
    parser.add_argument("--email")
    parser.add_argument("--name", default="Administrator")
    args = parser.parse_args()
    application = create_app()
    if args.command == "init-db":
        print("Database ready. Existing records are preserved.")
    elif args.command == "create-admin":
        email = args.email or input("Admin email: ")
        try:
            create_admin(application, email, args.name)
        except ValueError as error:
            parser.error(str(error))
    else:
        application.run(host="127.0.0.1", port=int(os.getenv("PORT", "5000")), debug=False)
